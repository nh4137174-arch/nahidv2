/* Replace these placeholders with the Web App config from Firebase Console. Never put service-account private keys here. */
export const firebaseConfig = {
  apiKey: "PASTE_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "PASTE_MESSAGING_SENDER_ID",
  appId: "PASTE_APP_ID"
};
/* Put your bKash Merchant Number here after confirming the exact merchant number. */
export const BKASH_MERCHANT_NUMBER = "01324392059";
