# Nahid Computer — Digital Service Website V2

এটি আপনার আগের Dark Navy + Neon Blue/Cyan ডিজাইন ধরে বানানো একটি Firebase-connected starter project। এখানে Public website, Google Login, customer profile, order submission, bKash Transaction ID submission, owner payment confirmation, status update, private file upload/download এবং payment-confirmed order-এর print/save-as-PDF invoice flow আছে।

**গুরুত্বপূর্ণ:** এই ZIP-এ bKash নম্বর 01324392059 বসানো হয়েছে। Firebase project config এখনো আপনার নিজস্ব Console থেকে বসাতে হবে। Owner Google email: nh4137174@gmail.com (Admin access UID দিয়ে সেট হবে, শুধু email লিখলেই Admin হবে না)। সেটআপ না করে সাইট publish করলে Login/Order কাজ করবে না। আগে test project-এ সেটআপ ও security rules পরীক্ষা করুন। GitHub Pages static hosting নিজে database, authentication বা private file storage দেয় না—সেজন্য Firebase দরকার।

## 1. ফাইলগুলো
- `index.html` — website UI
- `style.css` — responsive neon digital design + animation
- `app.js` — Firebase login, order, payment submission, admin panel, private file download, invoice
- `firebase-config.js` — আপনার Firebase Web config এবং bKash Merchant নম্বর বসানোর জায়গা
- `firestore.rules` — customer/admin database access rules
- `storage.rules` — private file rules (10 MB/file)

## 2. Firebase project তৈরি
1. `https://console.firebase.google.com/` খুলে Google account দিয়ে login করুন।
2. **Add project** চাপুন; যেমন `nahid-computer-digital` নাম দিন।
3. Project তৈরি হলে Project Overview থেকে Web icon `</>` চাপুন, app name দিন `Nahid Computer Website`, Register app করুন।
4. দেখানো `firebaseConfig` values কপি করুন। এগুলো `firebase-config.js`-এর একই নামের field-এ বসান। `YOUR_PROJECT_ID`-এর সব জায়গায় নিজের Project ID দিন। Firebase config client website-এ ব্যবহার করার জন্যই; কখনো service-account private key এখানে দেবেন না।
5. Firebase Console → **Authentication → Get started → Sign-in method → Google → Enable → Save**।
6. Authentication → **Settings → Authorized domains**-এ আপনার GitHub Pages domain যোগ করুন, যেমন `yourusername.github.io` (নিজের আসল GitHub username/domain বসাবেন)।
7. Build → **Firestore Database → Create database**। শুরুতে production mode বেছে নিয়ে Rules tab-এ `firestore.rules`-এর পুরো content paste করে Publish করুন।
8. Build → **Storage → Get started**। Rules tab-এ `storage.rules` paste করে Publish করুন। Storage চালুর জন্য Firebase account-এ billing/plan সংক্রান্ত শর্ত দেখালে Console-এ যা দেখায় তা আগে পড়ে নিন; খরচ হতে পারে।

## 3. bKash Merchant নম্বর বসানো
`firebase-config.js` খুলে এই লাইনটি খুঁজুন:

`export const BKASH_MERCHANT_NUMBER = "ADD_BKASH_MERCHANT_NUMBER_HERE";`

এই প্যাকেজে 01324392059 বসানো আছে—এটি আপনার আসল bKash Merchant নম্বর কি না প্রকাশের আগে নিশ্চিত করুন। এটি **ম্যানুয়াল পেমেন্ট যাচাই**—সাইট bKash-এর সঙ্গে স্বয়ংক্রিয়ভাবে যুক্ত নয়, পেমেন্ট API ব্যবহার করছে না। Customer Transaction ID ও amount জমা দেবে; Admin নিজের bKash merchant transaction history-তে যাচাই করে তবেই Confirm করবে। ভুল Transaction ID দিলে Confirm করবেন না।

## 4. Owner Admin account চালু করা
1. GitHub Pages-এ প্রথমে সাইট publish করুন, তারপর সাইটে নিজের Owner Google account দিয়ে একবার Login করুন।
2. Firebase Console → Authentication → Users-এ গিয়ে নিজের account-এর **User UID** কপি করুন।
3. Firestore Database → Data → Start collection / Add document করুন। Collection ID: `admins`; Document ID হিসেবে ঠিক ওই UID বসান। Field: `active` — Boolean — `true`।
4. Save করুন এবং website-এ Logout/Login বা refresh দিন। এরপর Admin Panel দেখা উচিত।
5. অন্য কাউকে `admins` collection-এ যোগ করবেন না। Admin document website থেকে তৈরি করা যায় না; Console থেকে Owner-ই সেট করবেন।

## 5. GitHub-এ website আপলোড
1. GitHub-এ আপনার `nahid-computer` repository খুলুন।
2. আগের ফাইলগুলোর backup রাখতে চাইলে আগে download/duplicate করে রাখুন।
3. এই ZIP extract করুন। ভেতরের ফাইলগুলো (folder-এর ভেতরের ফাইল, folder নিজে নয়) repository-এর root-এ upload করুন: `index.html`, `style.css`, `app.js`, `firebase-config.js`, `firestore.rules`, `storage.rules`, `README-BN.md`।
4. `firebase-config.js`-এ Firebase config ও Merchant নম্বর ঠিক করে commit করুন।
5. Repository → Settings → Pages → Branch `main`, Folder `/(root)` → Save। কিছুক্ষণ পরে GitHub Pages URL refresh করুন।
6. প্রথমে test account দিয়ে Google Login, profile save, test order, payment info, Admin confirmation এবং file upload/download পরীক্ষা করুন। এরপর public-কে ব্যবহার করতে দিন।

## 6. অর্ডার ও পেমেন্টের নিয়ম
- Mobile OTP নেই। Google Login বাধ্যতামূলক; প্রোফাইলে নাম ও মোবাইল নম্বর দিতে হবে।
- প্রতিটি order-এর জন্য `NC-YYYY-XXXXXX` ধাঁচের ID তৈরি হয়।
- Customer কাজের file প্রতি ফাইল সর্বোচ্চ 10 MB আপলোড করতে পারবে।
- Transaction ID + amount জমা দিলে Payment status `pending` হবে। Website নিজে টাকা পাওয়ার প্রমাণ যাচাই করতে পারে না। Owner bKash transaction history মিলিয়ে Admin Panel-এ `Confirm Payment` চাপবেন।
- Customer শুধু `Pending` order cancel করতে পারবে। Admin status `Received`, `Processing`, `Complete`, `Cancelled` করতে পারবে।
- Payment confirm হওয়ার পর customer PDF invoice তৈরি/Print → Save as PDF করতে পারবে। Invoice হলো website-generated receipt; এটি bKash-এর official receipt নয়।
- Final work file private Storage-এ থাকে; customer নিজের order-এর file এবং Owner access করতে পারে। Public download URL তৈরি করা হয় না।

## 7. এখনো আলাদা করে সেটআপ/যোগ করা বাকি
- **Email notifications:** এই starter-এর বর্তমান version-এ website dashboard/order status আছে; স্বয়ংক্রিয় email পাঠানো এখনো সক্রিয় নয়। Email চালু করতে নিরাপদ server-side Cloud Function বা Firebase Trigger Email Extension এবং sender verification/configuration করতে হবে। Client-side থেকে সরাসরি email পাঠানো নিরাপদ নয়।
- **Order email receipts / customer notification inbox:** পরের version-এ notification collection ও email trigger যুক্ত করা যাবে।
- **Price list management:** আপাতত public price section-এ “দাম জানতে অর্ডার দিন” লেখা আছে, যাতে ভুল/sample দাম না দেখায়। Admin price editor এখনো সম্পূর্ণ implement করা হয়নি; প্রকৃত মূল্য তালিকা দিলে আলাদা dynamic management যুক্ত করা উচিত।
- **Quotation acceptance:** Quote amount Owner set করে customer accept করবে—এ workflow পরের version-এ যুক্ত করা দরকার।
- **Invoice numbering / tax details:** বর্তমান invoice order number ব্যবহার করে। VAT/tax বা দোকানের নির্দিষ্ট invoice policy থাকলে আলাদা করে ঠিক করতে হবে।

## 8. Security notes
- Firebase Security Rules paste না করে site live করবেন না। Rules ভুল হলে private customer files expose হতে পারে।
- Firebase Web config website-এ থাকতে পারে; Service Account JSON/private keys কখনো GitHub-এ upload করবেন না।
- GitHub repository public হলে config values দেখা যায়; Firebase Security Rules-ই database/storage access control করে।
- প্রথমে নিজের test order দিয়ে পরীক্ষা করুন। Sensitive NID/password/document শুধু প্রয়োজন হলে আপলোড করতে বলুন।
- Firebase Storage/other services-এর current billing and free-tier limits Console-এ যাচাই করুন।
